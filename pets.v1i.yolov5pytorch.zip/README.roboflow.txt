
pets - v1 2021-04-01 11:28am
==============================

This dataset was exported via roboflow.ai on April 1, 2021 at 4:28 AM GMT

It includes 24 images.
Pets are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


